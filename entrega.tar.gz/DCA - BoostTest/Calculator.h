#ifndef _CALCULATOR_H_
#define _CALCULATOR_H_


class Calculator
{
public:
    Calculator();
    double Calculate(double x, char oper, double y);
};


#endif